# Upload this to your GitHub repo

1) On GitHub, open your repo.
2) Click **Add file → Upload files**.
3) Drag the **.github** folder from this zip and drop it into the repo root.
4) Commit directly to the `main` branch.
5) Go to the **Actions** tab → run **Android Release APK**.
6) Make sure your secrets are set in **Settings → Secrets and variables → Actions**:
   - SIGNING_KEYSTORE_BASE64
   - SIGNING_KEYSTORE_PASSWORD
   - SIGNING_KEY_ALIAS
   - SIGNING_KEY_PASSWORD
