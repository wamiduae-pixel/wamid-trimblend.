# How to use this workflow

1. Upload the `.github` folder to your GitHub repository root.
2. Commit directly to the `main` branch.
3. Make sure your repo has the following secrets under Settings → Secrets → Actions:
   - SIGNING_KEYSTORE_BASE64
   - SIGNING_KEYSTORE_PASSWORD
   - SIGNING_KEY_ALIAS
   - SIGNING_KEY_PASSWORD
4. Go to Actions → Android Release (Signed) → Run workflow → Run.
5. Download the signed APK from the workflow artifacts.
